#ifndef LCD_CFG_H_
#define LCD_CFG_H_




#define _4_BIT   0
#define _8_BIT   1





#endif /* LCD_CFG_H_ */
