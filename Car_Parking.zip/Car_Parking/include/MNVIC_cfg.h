#ifndef	MNVIC_CFG_H
#define MNVIC_CFG_H



#endif
