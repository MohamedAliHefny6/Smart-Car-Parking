/*********************************************************/
/******				ARM_Project  				    ******/
/******				SWC : TFT   					******/
/*********************************************************/

#ifndef TFT_CFG_H_
#define TFT_CFG_H_



/* Pin TFT A0: Adjusted to pin 0 */
#define TFT_A0           PIN0

/* Pin TFT RESET: Adjusted to pin 1 */
#define TFT_RESET        PIN1




#endif
