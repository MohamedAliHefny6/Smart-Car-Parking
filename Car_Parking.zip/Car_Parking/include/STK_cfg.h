#ifndef STK_CFG_H
#define STK_CFG_H



#define STK_CLK_SOURCE     STK_AHB_DIV_8
#define STK_INTERRPUT_EN   MSTK_INT_DISABLE





#endif
