/*********************************************************/
/******				ARM_Project  				    ******/
/******				SWC : TFT   					******/
/*********************************************************/

#ifndef TFT_PRV_H_
#define TFT_PRV_H_



/* Prototype of function: Reset sequence for the TFT display */
void TFT_voidReset(void);

/* Prototype of function: Write command to the TFT display */
void TFT_voidWriteCommand(u8 Copy_u8Cmd);

/* Prototype of function: Write data to the TFT display */
void TFT_voidWriteData(u8 Copy_u8Data);






#endif
